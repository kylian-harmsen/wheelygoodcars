@extends('layouts.app')

@section('content')
    <p>hoi</p>
@endsection
