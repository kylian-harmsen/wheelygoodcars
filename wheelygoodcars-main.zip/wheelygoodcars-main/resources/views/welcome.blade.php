@extends('layouts.app')
@section('content')
    Welkom!
@endsection
